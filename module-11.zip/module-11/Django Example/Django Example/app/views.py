"""
Definition of views.
"""

from datetime import datetime
from django.shortcuts import render, HttpResponse
from django.http import HttpRequest

def home(request):
    return HttpResponse("McCarthy says Hello!")
   # """Renders the home page."""
   # assert isinstance(request, HttpRequest)
   # return render(
   #     request,
     #   'app/index.html',
     #   {
     #       'title':'Home Page',
     #       'year':datetime.now().year,
      #  }
  #  )

#def contact(request):
   # """Renders the contact page."""
#assert isinstance(request, HttpRequest)
   # return render(
     #   request,
     #   'app/contact.html',
     #   {
      #      'title':'Contact',
       #     'message':'Your contact page.',
       #     'year':datetime.now().year,
      #  }
   # )

#def about(request):
   # """Renders the about page."""
   # assert isinstance(request, HttpRequest)
   # return render(
    #    request,
     #   'app/about.html',
    #    {
    #        'title':'About',
     #       'message':'Your application description page.',
    #        'year':datetime.now().year,
   #     }
   # )
